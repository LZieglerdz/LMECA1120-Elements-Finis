#include "fem.h"


# ifndef NOEXPAND

void edgesExpand(femEdges *theEdges)
{
    // A faire :-)
}

# endif
# ifndef NOSORT

void edgesSort(femEdges *theEdges)
{
	qsort(theEdges->edges, theEdges->nEdge, sizeof(femEdge), edgesCompare);
}

# endif
# ifndef NOCOMPARE

int edgesCompare(const void* e0, const void *e1)
{   
    // A MODIFIER //
    int diagnostic = ((femEdge*) e0)->node[0] - ((femEdge*) e1)->node[0];
    if (diagnostic < 0)     return 1;
    if (diagnostic > 0)     return -1;  
    // A MODIFIER //
    return 0;
}

# endif
# ifndef NOSHRINK

void edgesShrink(femEdges *theEdges)
{
    // Ici commence votre contribution a faire :-)

    int n = 0;          // Nouveau nombre total de segments : A MODIFIER
    int nBoundary = 0;  // Nombre de segments frontieres : A MODIFIER
    
    // Ici, finit votre contribution
    
    // Reallocation du tableau des edges
    
    theEdges->edges = realloc(theEdges->edges, n * sizeof(femEdge));
    theEdges->nEdge = n;
    theEdges->nBoundary = nBoundary;
}

# endif
# ifndef NOBOUNDARYLENGTH

double edgesBoundaryLength(femEdges *theEdges)
{
    double L = 777;
    return L;
}

# endif
