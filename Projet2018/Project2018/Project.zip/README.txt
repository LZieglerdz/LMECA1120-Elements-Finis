ENGLISH
-------

INSTALLING
----------

1) unzip file
2) execute in Linux terminal:
	cmake .
	make


EXECUTE PROGRAM
---------------

1) run myFem in terminal
	./myFem
2) enter desired number of grains
3) enter desired angular velocity (we recommend one between 0 and 4 Rads/s)
4) enter desired viscosity (only numbers, no special character. Example: enter 1e8 or 100000000 instead of 10^8)

---------------------------------------------------------------
---------------------------------------------------------------

FRANCAIS
--------

INSTALLATION
------------

1) Dezipper le dossier
2) executer dans un terminal Linux:
	cmake.
	make

EXECUTER LE PROGRAMME
---------------------

1) executer myFem dans le terminal
	./myFem
2) entrer le nombre de grains desire
3) entrer la vitesse angulaire desiree (nous en recommendons une entre 0 et 4 Rads/s)
4) entrer la viscositee desiree (uniquement des nombres. Pas de caracteres spéciaux comme "^". Exemple: entrer 1e8 ou 100000000 a la place de 10^8)


---------------------------------------------------------------
---------------------------------------------------------------
